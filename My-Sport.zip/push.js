var webPush = require('web-push');
 
const vapidKeys = {
   "publicKey": "BNHUoJNhmTed-7nfPRnW7B7wMDqJhq73azjYLHnXnHSlc0Iuxfhz8ZtjddLZH3yo2WslS8UFcJa7RB5q94fjZvg",
   "privateKey": "azzLL13pfgvdzMd6mQOI3A4onN94Kgjf7AaHg_7nHAA"
};
 
 
webPush.setVapidDetails(
   'mailto:example@yourdomain.org',
   vapidKeys.publicKey,
   vapidKeys.privateKey
)
var pushSubscription = {
   "endpoint": "https://fcm.googleapis.com/fcm/send/d6XwrBEsr_E:APA91bHlhJAI7kAGFIrJwHip-_Yv7OzbJ9T7d8Lsq0iIs4Ne2DEpbia1RP3pwvfV8SmXhAk99TlzPYBYlmBywAvou4Pifun7h3PuIzHcJ3FuYHsxYxuK8MdplxZP4_isRAIfeER-zudA"
   ,
   "keys": {
       "p256dh": "BPrZEr1dGm3HyriDs8G3tPrSzCA3ZHbWO5YPdwQrqz2TnAPJ5RjMqLaxB3HYI6bRXylyyqaLUl1SUve8hwXWuKU=",
       "auth": "C/7hc8ajd+V5nDbTkHtUUA=="
   }
};
var payload = 'Selamat datang di My-Sport';
 
var options = {
   gcmAPIKey: '365926314989',
   TTL: 60
};
webPush.sendNotification(
   pushSubscription,
   payload,
   options
);